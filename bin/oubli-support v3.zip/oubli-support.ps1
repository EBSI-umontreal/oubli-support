#=================================================
#D�tection de disquette, CDROM et cl� USB oubli�s
#
#Arnaud d'Alayer
#Conseiller de formation pratique en gestion de l'information num�rique
#EBSI - Universit� de Montr�al
#Pavillon Lionel Groulx, local C-2025
#T�l�phone  : +1 514 343-6111 poste 1040
#T�l�copieur: +1 514 343-5753
#http://grds.ebsi.umontreal.ca/dalayera/
#		
#Version : 2010-09-22 (version 3)
#		
#CHANGELOG:
#==========
#2011-09-22 v3		Conversion en PowerShell
#2010-11-12	v2.1	Mise � jour de la documentation pour Vista/7
#2008-06-05	v2		Version compatible XP SP3
#2006-02-23	v1		Version Originale
#		
#Cette cr�ation est mise � disposition selon le Contrat Paternit�-NonCommercial-ShareAlike2.5 Canada disponible en ligne http://creativecommons.org/licenses/by-nc-sa/2.5/ca/ ou par courrier postal � Creative Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.
#=================================================

#D�terminer le type de m�dia pour l'affichage du message
function typeLecteur([int] $type, [string] $lettre){
	if ($type -eq 4){
		"CD-ROM ou DVD"
	}
	else{
		if (($lettre -eq "A") -or ($lettre -eq "B")){
			"disquette"
		}
		else{
			"cl� USB"
		}
	}
}


function popup ([string] $message) {
	[console]::Beep()
	[console]::Beep()
	[console]::Beep()
	
	$popup =  new-object -comobject wscript.shell
	$popup.popup($message,0,"Attention",0)
}


#==== D�claration des variables ====
$fso = new-object -comobject Scripting.FileSystemObject
$listeLecteurs = $fso.Drives

$detecte = $false
$recommencer = $true
$message = ""


#==== D�but du programme ====
#Tant que l'utilisateur n'a pas retir� les supports de stockage, on �met le signal
while ($recommencer){
	#On efface le message pr�c�dent
	$message = ""

	#On d�tecte si des supports de stockage ont �t� oubli�s
	Foreach ($lecteur in $listeLecteurs){
		$lecteurLettre = $lecteur.DriveLetter
		$lecteurTypeCode = $lecteur.DriveType
		$lecteurTypeTexte = typeLecteur $lecteurTypeCode $lecteurLettre
		#Tester si le lecteur est une unit� de stockage amovible (1) ou un CD-ROM (4)
		if (($lecteurTypeCode -eq 1) -or ($lecteurTypeCode -eq 4)){
			#Tester si le lecteur poss�de un m�dia
			if ($lecteur.IsReady){
				$detecte = $true
				$message += "Vous avez OUBLI� votre {0} (lecteur {1})`n" -f $lecteurTypeTexte, $lecteurLettre
			 }
		}
	}
	#Si des supports de stockage ont �t� oubli�s, on alerte l'utilisateur
	if ($detecte){
		popup $message
        $detecte = $false
	}
	else{
		$recommencer=$false
	}
}
